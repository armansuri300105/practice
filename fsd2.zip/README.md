# EduSubmit — Assignment Submission & Evaluation System

## Tech Stack
- **Frontend**: Plain HTML, CSS, JavaScript (no frameworks)
- **Backend**: Node.js + Express.js
- **Database**: MongoDB (Mongoose ODM) — used for ALL data (users, assignments, submissions)

## Project Structure
```
assignment-app/
├── server.js              # Express server + all API routes
├── backend/
│   └── models.js          # Mongoose schemas (User, Assignment, Submission)
├── public/
│   ├── index.html         # Login / Register page
│   └── dashboard.html     # Dashboard (Faculty + Student)
└── package.json
```

## MongoDB Collections
| Collection    | Purpose                                      |
|---------------|----------------------------------------------|
| `users`       | Username, password (bcrypt), role            |
| `assignments` | Title, course, due_date, description         |
| `submissions` | Student answers, status, marks, comments     |

## API Endpoints
| Method | Route                | Auth | Description              |
|--------|----------------------|------|--------------------------|
| POST   | /register            | No   | Register new user        |
| POST   | /login               | No   | Login, returns JWT       |
| POST   | /assignment/create   | JWT  | Faculty creates assignment|
| GET    | /assignments         | JWT  | List all assignments     |
| POST   | /submit              | JWT  | Student submits answer   |
| GET    | /submissions         | JWT  | View submissions         |
| PUT    | /grade/:id           | JWT  | Faculty grades submission|

## Setup & Run

### Prerequisites
- Node.js installed
- MongoDB running locally on port 27017

### Steps
```bash
# 1. Install dependencies
npm install

# 2. Start MongoDB (if not running)
mongod --dbpath /data/db

# 3. Start the server
node server.js

# 4. Open browser
http://localhost:3000
```

## Usage
1. **Register** as `faculty` or `student`
2. **Faculty**: Create assignments → View submissions → Grade them
3. **Student**: View assignments → Submit answers → Track grades
